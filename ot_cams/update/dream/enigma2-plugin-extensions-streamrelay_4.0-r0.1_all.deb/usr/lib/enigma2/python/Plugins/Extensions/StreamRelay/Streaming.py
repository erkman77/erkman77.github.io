from Components.Converter.Converter import Converter
from Components.Element import cached
from Plugins.Extensions.StreamRelay.plugin import writelog
# the protocol works as the following:

# lines starting with '-' are fatal errors (no recovery possible),
# lines starting with '=' are progress notices,
# lines starting with '+' are PIDs to record:
# 	"+d:[p:t[,p:t...]]" with d=demux nr, p: pid, t: type

class Streaming(Converter):
	@cached
	def getText(self):
		service = self.source.service
		if service is None:
			return "-NO SERVICE\n"

		streaming = service.stream()
		s = streaming and streaming.getStreamingData()
		pids = s and s.get("pids", [] )
		demux = s and s.get("demux", None)
		
		if not s or not pids or demux is None:
			err = service.getError()
			if err:
				#writelog('{0} -SERVICE ERROR {1}'.format(self.source.ref and self.source.ref.toString(), err))
				return "-SERVICE ERROR:%d\n" % err
			else:
				#writelog('{0} =NO STREAM {1}'.format(self.source.ref and self.source.ref.toString(), err))
				return "=NO STREAM\n"
		
		pids = ','.join(["%x:%s" % (x[0], x[1]) for x in pids])
		if pids.find('pmt') == -1:
			#writelog('{0} =NO PMT'.format(self.source.ref and self.source.ref.toString() or 'No source.ref'))
			return "=NO STREAM\n"
		#writelog('demux {0} pids {1}'.format(demux, pids))
		return "+%d:%s\n" % (demux, pids)

	text = property(getText)
	

pidname = ["pat", "tdt", "eit", "pmt", "video", "audio", "pcr"]

class Streaming2(Converter):
	@cached
	def getText(self):
		service = self.source.service
		if service is None:
			return "-NO SERVICE\n"

		streaming = service.stream()
		s = streaming and streaming.getStreamingData()
		pids = s and s.get("pids", [] )
		demux = s and s.get("demux", None)
		
		if not s or not pids or demux is None:
			err = service.getError()
			if err:
				#writelog('{0} -SERVICE ERROR {1}'.format(self.source.ref and self.source.ref.toString(), err))
				return "-SERVICE ERROR:%d\n" % err
			else:
				#writelog('{0} =NO STREAM {1}'.format(self.source.ref and self.source.ref.toString(), err))
				return "=NO STREAM\n"
		
		pidsstr = "+%d:" % (demux)
		found_pmt = found_video = found_audio = found_pcr = False
		
		for index in range(len(pids)):
			key = pids[index][0]
			name = pids[index][1]
			if name in pidname:
				if index == 0:
					pidsstr += "%x:%s" % (key, name)
				else:
					pidsstr += ",%x:%s" % (key, name)
				if name == "pmt":
					found_pmt = True
				elif name == "video":
					found_video = True
				elif name == "audio":
					found_audio = True
				elif name == "pcr":
					found_pcr = True
		
		#writelog('pidsstr {0}'.format(pidsstr))
		if found_pmt and found_video and found_audio and found_pcr:
			pidsstr += '\n'
			return pidsstr
		#writelog('pidsstr {0}'.format(pidsstr))
		#writelog('pmt={0} video={1} audio={2} pcr={3}'.format(found_pmt, found_video, found_audio, found_pcr))
		return "=NO STREAM\n"

	text = property(getText)
	
	
class Streaming3(Converter):
	@cached
	def getText(self):
		service = self.source.service
		if service is None:
			return "-NO SERVICE\n"

		streaming = service.stream()
		s = streaming and streaming.getStreamingData()
		pids = s and s.get("pids", [] )
		demux = s and s.get("demux", None)
		
		if not s or not pids or demux is None:
			err = service.getError()
			if err:
				#writelog('{0} -SERVICE ERROR {1}'.format(self.source.ref and self.source.ref.toString(), err))
				return "-SERVICE ERROR:%d\n" % err
			else:
				#writelog('{0} =NO STREAM {1}'.format(self.source.ref and self.source.ref.toString(), err))
				return "=NO STREAM\n"
		
		pidsstr = "+%d:" % (demux)
		found_pmt = found_video = found_audio = found_pcr = False
		
		for index in range(len(pids)):
			key = pids[index][0]
			name = pids[index][1]
			if name in pidname:
				if index == 0:
					pidsstr += "%x:%s" % (key, name)
				else:
					pidsstr += ",%x:%s" % (key, name)
				if name == "pmt":
					found_pmt = True
				elif name == "video":
					found_video = True
				elif name == "audio":
					found_audio = True
				elif name == "pcr":
					found_pcr = True
		
		#writelog('pidsstr {0}'.format(pidsstr))
		if found_pmt and found_video and found_audio and found_pcr:
			pidsstr += '\n'
			self.source.havepids = True
			return pidsstr
		#writelog('pidsstr {0}'.format(pidsstr))
		#writelog('pmt={0} video={1} audio={2} pcr={3}'.format(found_pmt, found_video, found_audio, found_pcr))
		return "=NO STREAM\n"

	text = property(getText)
	
	

