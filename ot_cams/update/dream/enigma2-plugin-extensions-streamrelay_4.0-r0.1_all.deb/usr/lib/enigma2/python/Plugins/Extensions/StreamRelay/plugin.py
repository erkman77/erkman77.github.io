from enigma import eServiceReference, eServiceCenter, iServiceInformation, eTimer, iRecordableService, eDVBServicePMTHandler, eEPGCache, iPlayableService
from Plugins.Plugin import PluginDescriptor
from Screens.ChannelSelection import BouquetSelector, ChannelSelection
from Screens.MessageBox import MessageBox
from Components.config import config, ConfigSubsection, ConfigIP, ConfigInteger, ConfigText, getConfigListEntry, ConfigSelection, ConfigOnOff, NoSave, ConfigSelectionNumber
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from time import localtime

import json
from collections import OrderedDict
from Tools.Directories import pathExists, resolveFilename, SCOPE_CONFIG

try:
	from Plugins.Extensions.WebInterface.WebScreens import streamingScreens, streamingEvents
except:
	streamingScreens = []
	streamingEvents = []

from datetime import datetime
def writelog(text=''):
	print text
	with open('/tmp/streamrelay.log', "a") as fp:
		fp.write('{0} {1}\n'.format(datetime.today().strftime("%d.%m.%Y %H:%M:%S"),text))

def writeerror():
	from traceback import print_exc
	with open('/tmp/streamrelayerror.log', "a") as fp:
		print_exc(file=fp)

icamref = OrderedDict()
icamrefchanged = False
streamrelayconf = {}
streamrelayconf['icamref'] = False
#streamrelayconf['referencefix'] = False
streamrelayconf['streamhost'] = '127.0.0.1'
streamrelayconf['streamport'] = 17999
streamrelayconf['nameadd'] = ''
#streamrelayconf['noresources'] = False
streamrelayconf['recordstate'] = False
#streamrelayconf['requestfilter'] = False
streamrelayconf['requestfilter'] = 0
streamrelayconf['eventupdateonshow'] = False
streamrelayconf['switchrecording'] = False
streamrelayconf['stopstreamtostream'] = 0
streamrelayconf['stopstreamtotv'] = 0
streamrelayconf['noresourcescolor'] = 0

icamident = {}#{'compare':'','value':''}
icamident['compare'] = ''
icamident['servicestr'] = ''

mainstreamptr = []

ICAMREFDIR = resolveFilename(SCOPE_CONFIG, "icamref.json")
ICAMIDENTDIR = resolveFilename(SCOPE_CONFIG, "icamident.json")
STREAMRELAYCONFDIR = resolveFilename(SCOPE_CONFIG, "streamrelayconf.json")

class srvariabel(object):
	recslen = 0

def writestreamrelayconf():
	if streamrelayconf:
		tmp = {}
		if streamrelayconf['icamref'] != False:
			tmp['icamref'] = streamrelayconf['icamref']
		#if streamrelayconf['noresources'] != False:
		#	tmp['noresources'] = streamrelayconf['noresources']
		if streamrelayconf['noresourcescolor'] != 0:
			tmp['noresourcescolor'] = streamrelayconf['noresourcescolor']
		#if streamrelayconf['referencefix'] != False:
		#	tmp['referencefix'] = streamrelayconf['referencefix']
		if streamrelayconf['recordstate'] != False:
			tmp['recordstate'] = streamrelayconf['recordstate']
		#if streamrelayconf['requestfilter'] != False:
		#	tmp['requestfilter'] = streamrelayconf['requestfilter']
		if streamrelayconf['requestfilter'] != 0:
			tmp['requestfilter'] = streamrelayconf['requestfilter']
		if streamrelayconf['eventupdateonshow'] != False:
			tmp['eventupdateonshow'] = streamrelayconf['eventupdateonshow']
		if streamrelayconf['switchrecording'] != False:
			tmp['switchrecording'] = streamrelayconf['switchrecording']
		if streamrelayconf['streamhost'] != '127.0.0.1':
			tmp['streamhost'] = streamrelayconf['streamhost']
		if streamrelayconf['streamport'] != 17999:
			tmp['streamport'] = streamrelayconf['streamport']
		if streamrelayconf['stopstreamtostream'] != 0:
			tmp['stopstreamtostream'] = streamrelayconf['stopstreamtostream']
		if streamrelayconf['stopstreamtotv'] != 0:
			tmp['stopstreamtotv'] = streamrelayconf['stopstreamtotv']
		if streamrelayconf['nameadd'] != '':
			tmp['nameadd'] = streamrelayconf['nameadd']
		
		with open(STREAMRELAYCONFDIR, 'w') as fp:
			json.dump(OrderedDict(sorted(tmp.items(), key=lambda x: x[1])), fp, encoding='utf-8', indent=2, sort_keys=False, ensure_ascii=True)

def readstreamrelayconf():
	if pathExists(STREAMRELAYCONFDIR):
		with open(STREAMRELAYCONFDIR) as data_file:
			data = json.load(data_file, encoding='utf-8', object_pairs_hook=OrderedDict)
			if data.get('icamref'):
				streamrelayconf['icamref'] = data['icamref']
			#if data.get('noresources'):
			#	streamrelayconf['noresources'] = data['noresources']
			if data.get('noresourcescolor'):
				streamrelayconf['noresourcescolor'] = data['noresourcescolor']
			#if data.get('referencefix'):
			#	streamrelayconf['referencefix'] = data['referencefix']
			if data.get('recordstate'):
				streamrelayconf['recordstate'] = data['recordstate']
			#if data.get('requestfilter'):
			#	streamrelayconf['requestfilter'] = data['requestfilter']
				
			if data.get('requestfilter'):
				tmp = data['requestfilter']
				if not isinstance(tmp, bool):
					streamrelayconf['requestfilter'] = tmp
				else:
					streamrelayconf['requestfilter'] = 0
					
			if data.get('eventupdateonshow'):
				streamrelayconf['eventupdateonshow'] = data['eventupdateonshow']
			if data.get('switchrecording'):
				streamrelayconf['switchrecording'] = data['switchrecording']
			if data.get('streamhost'):
				streamrelayconf['streamhost'] = data['streamhost'].encode('utf-8')
			if data.get('streamport'):
				streamrelayconf['streamport'] = data['streamport']
			if data.get('stopstreamtostream'):
				streamrelayconf['stopstreamtostream'] = data['stopstreamtostream']
			if data.get('stopstreamtotv'):
				streamrelayconf['stopstreamtotv'] = data['stopstreamtotv']
			if 'nameadd' in data:
				streamrelayconf['nameadd'] = data['nameadd'].encode('utf-8')

def __writeicamref__():
	if icamref and icamrefchanged:
		with open(ICAMREFDIR, 'w') as fp:
			json.dump(OrderedDict(sorted(icamref.items(), key=lambda x: x[1])), fp, encoding='utf-8', indent=2, sort_keys=False, ensure_ascii=True)
	
	try:
		from os import remove as os_remove
		if icamident and icamident['compare']:
			service = None
			from Screens.InfoBar import InfoBar
			if InfoBar.instance:
				service = InfoBar.instance.session.nav.getCurrentlyPlayingServiceReference()
			if service and service.toCompareString() == icamident['compare']:
				with open(ICAMIDENTDIR, 'w') as fp:
					json.dump(OrderedDict(sorted(icamident.items(), key=lambda x: x[1])), fp, encoding='utf-8', indent=2, sort_keys=False, ensure_ascii=True)
			elif pathExists(ICAMIDENTDIR):
				os_remove(ICAMIDENTDIR)
		elif pathExists(ICAMIDENTDIR):
			os_remove(ICAMIDENTDIR)
	except:
		writeerror()
		
def readicamref():
	if pathExists(ICAMREFDIR):
		with open(ICAMREFDIR) as data_file:
			data = json.load(data_file, encoding='utf-8', object_pairs_hook=OrderedDict)
			for key, value in data.items():
				icamref[key] = value
	if pathExists(ICAMIDENTDIR):
		with open(ICAMIDENTDIR) as data_file:
			data = json.load(data_file, encoding='utf-8', object_pairs_hook=OrderedDict)
			if data.get('compare'):
				icamident['compare'] = data['compare'].encode('utf-8')
			if data.get('servicestr'):
				icamident['servicestr'] = data['servicestr'].encode('utf-8')
		from os import remove as os_remove
		os_remove(ICAMIDENTDIR)
		
#ptrdict = dict()
#ptrlist = []
'''
def checkstreaming_ok(stoprecord = False, toremove = False):
	ptrlist = []
	try:
		if streamingScreens:
			for streaming in streamingScreens:
				if streaming.has_key("StreamService"):
					service = streaming["StreamService"].getService()
					if service:
						ptr = service.getPtrString()
						if ptr not in ptrlist:
							#ptrlist.insert(0, ptr)
							ptrlist.append(ptr)
						if stoprecord:
							streaming["StreamService"].navcore.stopRecordService(service)
							streamingScreens.remove(streaming)
				else:
					if toremove:
						streamingScreens.remove(streaming)
	except:
		pass
	return ptrlist[:]
'''

def checkstreaming(stoprecord = False, toremove = False):
	ptrlist = []
	try:
		if streamingScreens:
			for streaming in streamingScreens:
				stream = streaming.get("StreamService")
				if stream:
					service = stream.getService()
					if service:
						ptr = service.getPtrString()
						if ptr not in ptrlist:
							ptrlist.append(ptr)
						if stoprecord:
							if stream.recordEvent in stream.navcore.record_event:
								stream.navcore.record_event.remove(stream.recordEvent)
							if stream._StreamService__service is not None:
								stream.navcore.stopRecordService(stream._StreamService__service)
								stream._StreamService__service = None
							if streaming in streamingScreens:
								streamingScreens.remove(streaming)
				else:
					if toremove:
						streamingScreens.remove(streaming)
	except:
		writeerror()
	return ptrlist[:]
	
def MycheckRecordings(session):
	try:
		recslen = 0
		recslist = session.nav.getRecordings()
		if recslist:
			for recs in recslist:
				if recs.getPtrString() not in mainstreamptr:
					recslen += 1
		return recslen
	except:
		writeerror()
	return len(session.nav.getRecordings())


class StreamRelaySetup(Screen, ConfigListScreen):
	skin = """
		<screen name="StreamRelaySetup" position="center,170" size="1200,820" title="Setup">
		<layout name="Button_Small"/>
		<layout name="Button_Small_source"/>
		<widget enableWrapAround="1" name="config" position="10,90" scrollbarMode="showOnDemand" size="1180,720"/>
		</screen>"""
	
	def __init__(self, session):
		
		Screen.__init__(self, session)
		self.skinName = "StreamRelaySetup"
		ConfigListScreen.__init__(self, [], session=session)

		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_blue"] = StaticText(_("Reset"))
		self["key_yellow"] = StaticText(_("Repeatzap"))
		
		self["actions"] = ActionMap(["SetupActions", "ColorActions", "InfobarActions", "ChannelSelectEPGActions"],
			{
				"cancel": self.keyCancel,
				"red": self.keyCancel,
				"blue": self.keyblue,
				"yellow": self.keyyellow,
				"save": self.keySave,
				"showMovies": self.keykey_1,
				"showTv": self.keykey_2,
				"showRadio": self.keykey_3,
				"showEPGList": self.StreamrelayInfo,
			})
			
		self.settings = ConfigSubsection()
		self.settings.icamref = NoSave(ConfigOnOff(default = streamrelayconf['icamref']))
		#self.settings.noresources = NoSave(ConfigOnOff(default = streamrelayconf['noresources']))
		#self.settings.referencefix = NoSave(ConfigOnOff(default = streamrelayconf['referencefix']))
		self.settings.recordstate = NoSave(ConfigOnOff(default = streamrelayconf['recordstate']))
		#self.settings.requestfilter = NoSave(ConfigOnOff(default = streamrelayconf['requestfilter']))
		self.settings.eventupdateonshow = NoSave(ConfigOnOff(default = streamrelayconf['eventupdateonshow']))
		self.settings.switchrecording = NoSave(ConfigOnOff(default = streamrelayconf['switchrecording']))
		#self.settings.streamhost = NoSave(ConfigIP(default = streamrelayconf['streamhost'].split('.'), auto_jump=True))
		self.settings.streamhost = NoSave(ConfigText(default = streamrelayconf['streamhost'], fixed_size=False))
		self.settings.streamport = NoSave(NoSave(ConfigInteger(default=streamrelayconf['streamport'], limits=(1, 65555))))
		self.settings.nameadd = NoSave(ConfigText(default = streamrelayconf['nameadd'], fixed_size=False))
		
		self.settings.stopstreamtostream = NoSave(ConfigSelectionNumber(min=0,max=3000,stepwidth=50,default = streamrelayconf['stopstreamtostream'], wraparound=True))
		self.settings.stopstreamtotv = NoSave(ConfigSelectionNumber(min=0,max=3000,stepwidth=50,default = streamrelayconf['stopstreamtotv'], wraparound=True))
		
		self.settings.requestfilter = NoSave(ConfigSelection(default = str(streamrelayconf['requestfilter']), choices = [("0", _("Disabled")), ("1", _("normal")), ("2", _("medium")), ("3", _("strong"))]))
		
		self.settings.noresourcescolor = NoSave(ConfigSelection(default = str(streamrelayconf['noresourcescolor']), choices = [("0", _("Disable")), ("1", _('No free tuner!') + ' ' + _("disable")), ("2", _('Channel Selection') + ' ' + _('Color') + ' ' + _("disable")), ("3", _("All") + ' ' + _("disable"))]))
		
		self.changeicamref = streamrelayconf['icamref']
		#self.changenoresources = streamrelayconf['noresources']
		self.changerecordstate = streamrelayconf['recordstate']
		self.changerequestfilter = streamrelayconf['requestfilter']
		self.changeeventupdateonshow = streamrelayconf['eventupdateonshow']
		self.onLayoutFinish.append(self.firststart)
		self.helpwin = None
		self._createSetup()
	
	def KeyText(self):
		curr = self["config"].getCurrent()
		if curr and isinstance(curr[1], ConfigText):
			ConfigListScreen.KeyText(self)
			
	'''def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		curr = self["config"].getCurrent()
		if curr and curr[1] == self.settings.referencefix:
			self._createSetup()
	
	def keyRight(self):
		ConfigListScreen.keyRight(self)
		curr = self["config"].getCurrent()
		if curr and curr[1] == self.settings.referencefix:
			self._createSetup()'''
		
	def firststart(self):
		self.setTitle("Stream Relay " + _("Setup"))
		
	def _createSetup(self):
		entries = []
		entries.append(getConfigListEntry('Stream Host ' + _('Default') + ' (127.0.0.1)', self.settings.streamhost))
		entries.append(getConfigListEntry('Stream Port ' + _('Default') + ' (17999)', self.settings.streamport))
		entries.append(getConfigListEntry('Name ' + _('advanced'), self.settings.nameadd))
		#entries.append(getConfigListEntry(_('No free tuner!') + ' ' + ' / ' + _('Channel Selection') + ' ' + _('Color') + ' ' + _("disable"), self.settings.noresources))
		entries.append(getConfigListEntry(_('No free tuner!') + ' ' + ' / ' + _('Channel Selection') + ' ' + _('Color'), self.settings.noresourcescolor))
		entries.append(getConfigListEntry(_('Record') + ' ' + _('blinking') + ' ' + _("disable"), self.settings.recordstate))
		entries.append(getConfigListEntry(_('request pmt error filter') + ' ' + _("enable"), self.settings.requestfilter))
		entries.append(getConfigListEntry(_('Event update Infobar onshow and EPG filter') + ' ' + _("enable"), self.settings.eventupdateonshow))
		#entries.append(getConfigListEntry(_('Automatically switch recording if necessary') + '. ' + _('no support timer plausibility check') + ' ' + _("enable"), self.settings.switchrecording))
		entries.append(getConfigListEntry(_('Automatically switch recording if necessary') + ' / ' + _('Auto Convert icamref record') + ' ' + _("enable"), self.settings.switchrecording))
		#entries.append(getConfigListEntry('Auto Convert icamref / ' + _('Namespace') + ' (ID=33 / 0x21)', self.settings.icamref))
		
		entries.append(getConfigListEntry('Stop service before stream service start in ms. (min 150/0=disabled)', self.settings.stopstreamtostream))
		entries.append(getConfigListEntry('Stop stream service before TV service start if required in ms. (min 150/0=disabled)', self.settings.stopstreamtotv))
		
		entries.append(getConfigListEntry('Auto Convert icamref' + ' ' + _('enable'), self.settings.icamref))
		'''if self.settings.referencefix.value:
			#entries.append(getConfigListEntry(_('Service') + ' ' + _('Type') + '=1 ' + _('Transponder') + ' (ID=11 / 0xB) ' + _('Network') + ' (ID=22 / 0x16)', self.settings.referencefix))
			entries.append(getConfigListEntry(_('Service reference') + ' 1:0:1:xxxx:B:16:21:0:0:0:' , self.settings.referencefix))
		else:
			entries.append(getConfigListEntry(_('Service reference') + ' 1:0:x:xxxx:x:xx:21:0:0:0:' , self.settings.referencefix))'''
		self["config"].list = entries
		
	def keySave(self):
		if self["config"].isChanged():
			streamrelayconf['icamref'] = self.settings.icamref.value
			#streamrelayconf['noresources'] = self.settings.noresources.value
			streamrelayconf['recordstate'] = self.settings.recordstate.value
			#streamrelayconf['requestfilter'] = self.settings.requestfilter.value
			streamrelayconf['requestfilter'] = int(self.settings.requestfilter.value)
			streamrelayconf['eventupdateonshow'] = self.settings.eventupdateonshow.value
			streamrelayconf['switchrecording'] = self.settings.switchrecording.value
			streamrelayconf['streamhost'] = self.settings.streamhost.getText()
			streamrelayconf['streamport'] = self.settings.streamport.value
			streamrelayconf['nameadd'] = self.settings.nameadd.getText()
			streamrelayconf['noresourcescolor'] = int(self.settings.noresourcescolor.value)
			
			sts = int(self.settings.stopstreamtostream.value)
			if sts != 0 and sts < 150:
				sts = 150
			streamrelayconf['stopstreamtostream'] = sts
			stv = int(self.settings.stopstreamtotv.value)
			if stv != 0 and stv < 150:
				stv = 150
			streamrelayconf['stopstreamtotv'] = stv
			
			#if self.settings.icamref.value:
			#streamrelayconf['referencefix'] = self.settings.referencefix.value
			#else:
			#	streamrelayconf['referencefix'] = False
			
			writestreamrelayconf()
			#if (self.changeicamref != streamrelayconf['icamref']) or (self.changenoresources != streamrelayconf['noresources']) \
			#or (self.changerecordstate != streamrelayconf['recordstate']) or (self.changerequestfilter != streamrelayconf['requestfilter']) \
			#or (self.changeeventupdateonshow != streamrelayconf['eventupdateonshow']):
			restartbox = self.session.openWithCallback(self.restartGUI, MessageBox,_("GUI needs a restart to apply the new settings.\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)
			restartbox.setTitle(_("Restart GUI now?"))
			#else:
			#	self.close(True)
		else:
			self.close(False)
	
	def keyblue(self):
		self.settings.streamhost.value = '127.0.0.1'
		self.settings.streamport.value = 17999
		#self.settings.noresources.value = False
		#self.settings.requestfilter.value = False
		self.settings.requestfilter.value = "0"
		self.settings.eventupdateonshow.value = False
		self.settings.recordstate.value = False
		self.settings.switchrecording.value = False
		self.settings.icamref.value = False
		self.settings.nameadd.value = ''
		self.settings.stopstreamtostream.value = '0'
		self.settings.stopstreamtotv.value = '0'
		self.settings.noresourcescolor.value = '0'
		self._createSetup()
	
	def keyyellow(self):
		#curr = self["config"].getCurrent()
		#if curr and getattr(curr[1], 'help_window', None):
		#	helpwin = self._getHelpWindow()
		#	if helpwin:
		#		helpwin.hide()
		#self.session.open(repeatzap)
		openrepeatzap(self.session)
		#service = self.session.nav.getCurrentlyPlayingServiceReference()
		#if service:
		#	self.session.nav.playService(service, forceRestart = True)
		self.close(True)
		
	def keykey_1(self):
		self.settings.streamhost.value = '127.0.0.1'
		self._createSetup()
		
	def keykey_2(self):
		self.settings.streamhost.value = '192.168.2.124'
		self._createSetup()
		
	def keykey_3(self):
		self.settings.streamhost.value = '192.168.2.129'
		self._createSetup()
		
	def restartGUI(self, answer):
		if answer:
			from Screens.Standby import TryQuitMainloop
			self.session.open(TryQuitMainloop, 3)
			#from twisted.internet import reactor
			#reactor.callLater(1, self.session.open, TryQuitMainloop, 3)
		self.close(True)

	def StreamrelayInfo(self):
		self.helpwin = None
		curr = self["config"].getCurrent()
		if curr and getattr(curr[1], 'help_window', None):
			self.helpwin = self._getHelpWindow()
			if self.helpwin:
				self.helpwin.hide()
		
		#service = self.session.nav.getCurrentlyPlayingServiceReference()
		#info = eServiceCenter.getInstance().info(service)
		service = self.session.nav.getCurrentService()
		info = service and service.info()
		name = info and info.getName().replace('\xc2\x86', '').replace('\xc2\x87', '')
		sserviceref = info and info.getInfoString(iServiceInformation.sServiceref)
	
		text = '{0}\n{1}\n'.format(name, sserviceref.replace('%3a',':'))
		#text = '{0}\n{1}\n'.format(name, service.toString().replace('%3a',':'))
		#if mainstreamptr:
		text += 'mainstreamptr len ({0}) ptr {1}\n'.format(len(mainstreamptr),', '.join(mainstreamptr))
		ptrlistval = checkstreaming()
		text += 'checkstreaming len ({0}) ptr {1}\n'.format(len(ptrlistval), ', '.join(ptrlistval))
		text += 'streamingScreens len ({0})\n'.format(len(streamingScreens))
		text += 'streamingEvents len ({0})\n'.format(len(streamingEvents))
		text += 'MycheckRecordings ({0})\n'.format(MycheckRecordings(self.session))
		recslist = self.session.nav.getRecordings()
		recsptr = []
		for recs in recslist:
			if recs:
				recsptr.append(recs.getPtrString())
		text += 'getRecordings len ({0}) ptr {1}\n'.format(len(recslist), ', '.join(recsptr))
		import NavigationInstance
		if NavigationInstance.instance:
			recslistpnav = NavigationInstance.instance.pnav and NavigationInstance.instance.pnav.getRecordings(False)
			recsptrpnav = []
			for recs in recslistpnav:
				if recs:
					recsptrpnav.append(recs.getPtrString())
			text += 'pnav.getRecordings len ({0}) ptr {1}\n'.format(len(recslistpnav), ', '.join(recsptrpnav))
		#writelog('{0}{1}'.format(text, '#'*50))
		recservice = getRecordableServicePtr()
		if recservice:
			streaming = recservice.stream()
			#frontendinfo = recservice.frontendInfo().getFrontendData()
		else:
			streaming = service.stream()
			#frontendinfo = service.frontendInfo().getFrontendData()
		streamingdata = streaming and streaming.getStreamingData()
		#pids = s and s.get("pids", [] )
		#demux = s and s.get("demux", None)
		#pidsstr = ','.join(["%x:%s" % (x[0], x[1]) for x in pids])
		if streamingdata:
			pids = streamingdata and streamingdata.get("pids", [] )
			demux = streamingdata and streamingdata.get("demux", None)
			text += 'demuxer ({})  pids len ({})\npids {}\n'.format(demux, len(pids), pids)
		
		#frontendinfo = service.frontendInfo().getAll(True)
		#if frontendinfo:
		#	text += 'FrontendData\n{}\n'.format(frontendinfo)
		#writelog('\n{0}\n{1}\n{2}'.format('#'*80, text, '#'*80))
		self.session.openWithCallback(self.MessageBoxCallback, MessageBox, text, MessageBox.TYPE_INFO, title='Streamrelay' + ' ' + _('Information'))
		#if helpwin:
		#	helpwin.show()
	def MessageBoxCallback(self,res=None):
		if self.helpwin:
			self.helpwin.show()
			
def addicambouquet(session, service, csel, **kwargs):
	if service and csel:
		def bouquetCallback(bouquet):
			_result_ = getattr(csel, '_addicambouquetresult_', None)
			if _result_:
				name = _result_[0]
				servicestr = _result_[1]
				delattr(csel, '_addicambouquetresult_')
				
				if streamrelayconf['nameadd']:
					name += ' ' + streamrelayconf['nameadd']
				
				'''service.type = 1
				if streamrelayconf['referencefix']:
					service.setUnsignedData(0, 1)
					service.setUnsignedData(2, 11)
					service.setUnsignedData(3, 22)'''
			
				service.setUnsignedData(4, 33)
				service.setName('{0}'.format(name))
				service.setPath('http://{0}:{1}/{2}'.format(streamrelayconf['streamhost'], streamrelayconf['streamport'], servicestr))
				if isinstance(service, eServiceReference):
					csel.addServiceToBouquet(bouquet, service=service)
					from ServiceReference import ServiceReference
					serviceref = ServiceReference(bouquet)
					def messCallback(val=None):
						bouquetSel.close()

					servicestr = service.toString()
					servicestr = servicestr[:servicestr.find('http')]
					text = '{0}\n\n{1} {2}\n{3} {4}\n{5} {6}'.format(_("Added: "), _('Bouquet'), serviceref.getServiceName(), _('Channel'), name, _('Service reference'), servicestr)
					session.openWithCallback(messCallback, MessageBox, text, MessageBox.TYPE_INFO, timeout=3)
			
		bouquets = csel.getBouquetList()
		bouquetSel = session.open(BouquetSelector, bouquets, bouquetCallback, enableWrapAround=True)

def addicambouquethelperfnc(csel):
	if csel and csel.movemode == False:
		try:
			service = csel.getCurrentSelection()
			if service:
				serviceHandler = eServiceCenter.getInstance()
				info = serviceHandler.info(service)
				if info and info.getInfo(service, iServiceInformation.sIsCrypted) == 1:
					name = (info.getName(service) or "<n/a>").replace('\xc2\x86', '').replace('\xc2\x87', '')
					servicestr = service.toString()
					if servicestr:
						setattr(csel, '_addicambouquetresult_', (name, servicestr))
						return True
		except:
			return False
	return False
	
def addicamrefhelperfnc(csel):
	if csel and csel.movemode == False and streamrelayconf['icamref']:
		try:
			service = csel.getCurrentSelection()
			if service:
				serviceHandler = eServiceCenter.getInstance()
				info = serviceHandler.info(service)
				if info and info.getInfo(service, iServiceInformation.sIsCrypted) == 1:
					name = (info.getName(service) or "<n/a>").replace('\xc2\x86', '').replace('\xc2\x87', '')
					servicestr = service.toString()
					if servicestr:
						setattr(csel, '_icamresult_', {servicestr:name})
						return True
		except:
			return False
	return False
	
def addicamref(session, service, csel, **kwargs):
	if service and csel:
		_icamresult_ = getattr(csel, '_icamresult_', None)
		if _icamresult_:
			global icamrefchanged
			icamrefchanged = True
			
			name = _icamresult_.values()[0]
			servicestr = _icamresult_.keys()[0]
			
			if servicestr and servicestr in icamref:
				del icamref[servicestr]
				textvalu = _('Removed successfully.')
			else:
				icamref.update(_icamresult_)
				textvalu = _('Added: ')
			delattr(csel, '_icamresult_')
			text = '{0}\n\n{1} {2}\n{3} {4}'.format(textvalu, _('Channel'), name, _('Service reference'), servicestr)
			session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=3)
"""
def infobarstart(session, **kwargs):
	
	from Screens.InfoBar import InfoBar
	'''if InfoBar.instance and streamrelayconf['recordstate']:
		StreamRelayInfoinstantiateDialog = session.instantiateDialog(StreamRelayInfo, zPosition=-1)
		StreamRelayInfoinstantiateDialog.neverAnimate()
		InfoBar.instance.onShow.append(StreamRelayInfoinstantiateDialog.toggleShow)
		InfoBar.instance.onHide.append(StreamRelayInfoinstantiateDialog.hide)'''
	if InfoBar.instance and streamrelayconf['eventupdateonshow']:
		InfoBar._eventupdateonshow_ = _eventupdateonshow_
		InfoBar.instance.onShow.append(InfoBar.instance._eventupdateonshow_)
	
	if InfoBar.instance and streamrelayconf['noresources']:
		InfoBar._my_doReconnect_ = _my_doReconnect_
		InfoBar._my_reconnTimer = eTimer()
		InfoBar._my_reconnTimer_conn = InfoBar._my_reconnTimer.timeout.connect(InfoBar.instance._my_doReconnect_)
	
	if InfoBar.instance and streamrelayconf['icamref']:
		InfoBar.instance.onClose.append(__writeicamref__)
		orizap = ChannelSelection.zap
		#orizap = InfoBar.instance.servicelist.zap
		serviceHandler = eServiceCenter.getInstance()
	
		def convertref(nref, name, servicestr):
			if streamrelayconf['nameadd']:
				name += ' ' + streamrelayconf['nameadd']
			'''nref.type = 1
			if streamrelayconf['referencefix']:
				nref.setUnsignedData(0, 1)
				nref.setUnsignedData(2, 11)
				nref.setUnsignedData(3, 22)'''
			
			nref.setUnsignedData(4, 33)
			nref.setName('{0}'.format(name))
			nref.setPath('http://{0}:{1}/{2}'.format(streamrelayconf['streamhost'], streamrelayconf['streamport'], servicestr))
			
			icamident['compare'] = nref.toCompareString()
			icamident['servicestr'] = servicestr
			
		def zap(self, nref=None, root=None):
		#def zap(nref=None, root=None):
			if not nref:
				nref = self.getCurrentSelection()
				#nref = InfoBar.instance.servicelist.getCurrentSelection()
				if nref:
					info = serviceHandler.info(nref)
					if info:
						#if streamingScreens:
						#	checkstreaming()
						if info.getInfo(nref, iServiceInformation.sIsCrypted) == 1:
							servicestr = nref.toString()
							if servicestr and icamref and servicestr in icamref:
								#name = (icamref[servicestr] and icamref[servicestr].encode('utf-8')) or (info.getName(nref) or "<n/a>").replace('\xc2\x86', '').replace('\xc2\x87', '') or '<n/a>'
								name = (info.getName(nref) or "").replace('\xc2\x86', '').replace('\xc2\x87', '') or (icamref[servicestr] and icamref[servicestr].encode('utf-8')) or '<n/a>'
								#self.setCurrentSelection(eServiceReference(servicestr))
								convertref(nref, name, servicestr)
								#self.setCurrentSelection(nref)
								#writelog('zap {0} {1}'.format(name, servicestr))
								#InfoBar.instance.session.nav.stopService()
							else:
								icamident.clear()
			orizap(self, nref, root)
			#orizap(nref, root)
		
		readicamref()
		ChannelSelection.zap = zap
		#InfoBar.instance.servicelist.zap = zap
"""

def infobarstart_new(session, **kwargs):
	try:
		from Screens.InfoBar import InfoBar
		if InfoBar.instance:
			stopstreamtotv = streamrelayconf['stopstreamtotv']
			stopstreamtostream = streamrelayconf['stopstreamtostream']
			streamhost = streamrelayconf['streamhost']
			streamport = streamrelayconf['streamport']
			nameadd =  streamrelayconf['nameadd']
			icamrefenable = streamrelayconf['icamref']
			
			serviceHandler = eServiceCenter.getInstance()
			if icamrefenable or streamrelayconf['switchrecording']:
				readicamref()
				InfoBar.instance.onClose.append(__writeicamref__)
				
			if streamrelayconf['eventupdateonshow']:
				InfoBar._eventupdateonshow_ = _eventupdateonshow_
				InfoBar.instance.onShow.append(InfoBar.instance._eventupdateonshow_)
				
			if streamrelayconf['noresourcescolor'] > 0 or stopstreamtotv > 0 or stopstreamtostream > 0:
				InfoBar._sr_currentref_ = None
				InfoBar._sr_playservice_ = _sr_playservice_
				InfoBar._sr_playServiceTimer = eTimer()
				InfoBar._sr_playServiceTimer_conn = InfoBar._sr_playServiceTimer.timeout.connect(InfoBar.instance._sr_playservice_)
			
			def stop_start_service_timer(self, _sr_currentref_=None, timertime=0):
				self.session.nav.stopService()
				InfoBar.instance.serviceStarted()
				InfoBar.instance._sr_currentref_ = _sr_currentref_
				InfoBar.instance._sr_playServiceTimer.start(timertime, True)
				
			
			def convertref(nref, name, servicestr):
				if nameadd:
					name += ' ' + nameadd
				nref.setUnsignedData(4, 33)
				nref.setName('{0}'.format(name))
				nref.setPath('http://{0}:{1}/{2}'.format(streamhost, streamport, servicestr))
			
				icamident['compare'] = nref.toCompareString()
				icamident['servicestr'] = servicestr
				#writelog('convertref {0} {1}'.format(name, servicestr))
			
			if icamrefenable and stopstreamtotv == 0 and stopstreamtostream == 0:
				
				def sr_zap(self, nref=None, root=None):
					try:
						if not nref:
							nref = self.getCurrentSelection()
						if nref:
							service_info = serviceHandler.info(nref)
							if service_info:
								if service_info.getInfo(nref, iServiceInformation.sIsCrypted) == 1:
									servicestr = nref.toString()
									if servicestr and icamref and servicestr in icamref:
										name = (service_info.getName(nref) or "").replace('\xc2\x86', '').replace('\xc2\x87', '') or (icamref[servicestr] and icamref[servicestr].encode('utf-8')) or '<n/a>'
										convertref(nref, name, servicestr)
									else:
										icamident.clear()
						self.sr_orizap(nref, root)
					except:
						writeerror()
						
				from Screens.ChannelSelection import ChannelSelection
				ChannelSelection.sr_orizap = ChannelSelection.zap
				ChannelSelection.zap = sr_zap
					
			
			elif icamrefenable or stopstreamtotv > 0 or stopstreamtostream > 0:
				
				def sr_setHistoryPath(self):
					try:
						path = self.history[self.history_pos][:]
						ref = path.pop()
						del self.servicePath[:]
						self.servicePath += path
						self.saveRoot()
						root = path[-1]
						cur_root = self.getRoot()
						if cur_root and cur_root != root:
							self.setRoot(root)
		
						service_info = serviceHandler.info(ref)
						sr_cur_ref = self.session.nav.getCurrentlyPlayingServiceReference()
						isPlayable = sr_cur_ref and service_info and service_info.isPlayable(ref, sr_cur_ref)
		
						if service_info and stopstreamtotv > 0 and isPlayable == 0 and sr_cur_ref.getUnsignedData(4) == 33:
						#if service_info and stopstreamtotv > 0 and isPlayable == 0:
							self.stop_start_service_timer(ref, stopstreamtotv)
							#self.session.nav.stopService()
							#InfoBar.instance.serviceStarted()
							#if InfoBar.instance._sr_playServiceTimer.isActive() == False:
							#InfoBar.instance._sr_currentref_ = ref
							#InfoBar.instance._sr_playServiceTimer.stop()
							#InfoBar.instance._sr_playServiceTimer.start(stopstreamtotv, True)
						#elif service_info and stopstreamtostream > 0 and ref.getUnsignedData(4) == 33 and sr_cur_ref.getUnsignedData(4) == 33:
						elif service_info and stopstreamtostream > 0 and isPlayable == 1 and ref.getUnsignedData(4) == 33:
						#elif service_info and stopstreamtostream > 0 and isPlayable == 1 and ref.getUnsignedData(4) == 33 and sr_cur_ref.getUnsignedData(4) == 33:
							self.stop_start_service_timer(ref, stopstreamtostream)
							#self.session.nav.stopService()
							#InfoBar.instance.serviceStarted()
							#if InfoBar.instance._sr_playServiceTimer.isActive() == False:
							#InfoBar.instance._sr_currentref_ = ref
							#InfoBar.instance._sr_playServiceTimer.stop()
							#InfoBar.instance._sr_playServiceTimer.start(stopstreamtostream, True)
						else:
							self.session.nav.playService(ref)
		
						self.setCurrentSelection(ref)
						self.saveChannel(ref)
					except:
						writeerror()
				
				def sr_zap_all(self, nref=None, root=None):
					try:
						self.revertMode=None
						ref = self.session.nav.getCurrentlyPlayingServiceReference()
						service_info = None
						if not nref:
							nref = self.getCurrentSelection()
							if nref:
								service_info = serviceHandler.info(nref)
								if icamrefenable and service_info:
									if service_info.getInfo(nref, iServiceInformation.sIsCrypted) == 1:
										servicestr = nref.toString()
										if servicestr and icamref and servicestr in icamref:
											name = (service_info.getName(nref) or "").replace('\xc2\x86', '').replace('\xc2\x87', '') or (icamref[servicestr] and icamref[servicestr].encode('utf-8')) or '<n/a>'
											convertref(nref, name, servicestr)
										else:
											icamident.clear()
			
						if root:
							if not self.preEnterPath(root):
								self.clearPath()
								self.enterPath(eServiceReference(root))
						if ref is None or ref != nref:
							self.new_service_played = True
			
							if ref and service_info:			
								
								isPlayable = service_info.isPlayable(nref, ref)
								
								if stopstreamtotv > 0 and isPlayable == 0 and ref.getUnsignedData(4) == 33:
								#if stopstreamtotv > 0 and isPlayable == 0:
									self.stop_start_service_timer(nref, stopstreamtotv)
									#self.session.nav.stopService()
									#InfoBar.instance.serviceStarted()
									#if InfoBar.instance._sr_playServiceTimer.isActive() == False:
									#InfoBar.instance._sr_currentref_ = nref
									#InfoBar.instance._sr_playServiceTimer.stop()
									#InfoBar.instance._sr_playServiceTimer.start(stopstreamtotv, True)
								#elif stopstreamtostream > 0 and ref.getUnsignedData(4) == 33 and nref.getUnsignedData(4) == 33:
								elif stopstreamtostream > 0 and isPlayable == 1 and nref.getUnsignedData(4) == 33:
								#elif stopstreamtostream > 0 and isPlayable == 1 and nref.getUnsignedData(4) == 33 and ref.getUnsignedData(4) == 33:
									self.stop_start_service_timer(nref, stopstreamtostream)
									#self.session.nav.stopService()
									#InfoBar.instance.serviceStarted()
									#if InfoBar.instance._sr_playServiceTimer.isActive() == False:
									#InfoBar.instance._sr_currentref_ = nref
									#InfoBar.instance._sr_playServiceTimer.stop()
									#InfoBar.instance._sr_playServiceTimer.start(stopstreamtostream, True)
						
								else:
									self.session.nav.playService(nref, forceRestart=True)
							else:
								self.session.nav.playService(nref)
			
							self.saveRoot()
							self.saveChannel(nref)
							config.servicelist.lastmode.save()
							self.addToHistory(nref)
					except:
						writeerror()
						
				from Screens.ChannelSelection import ChannelSelection
				ChannelSelection.zap = sr_zap_all
				ChannelSelection.setHistoryPath = sr_setHistoryPath
				ChannelSelection.stop_start_service_timer = stop_start_service_timer
	except:
		writeerror()
		
def setup(session, **kwargs):
	session.open(StreamRelaySetup)

def openrepeatzap(session, **kwargs):
	service = session.nav.getCurrentlyPlayingServiceReference()
	if service:
		def resback(val=None):
			session.nav.playService(service, forceRestart = True)
		session.nav.stopService()
		restartbox = session.openWithCallback(resback, MessageBox,_("Repeatzap"), MessageBox.TYPE_INFO, timeout=3,windowTitle='Streamrelay')
		#restartbox.setTitle(_("repeatzap"))
	
		
	#session.open(repeatzap)
	
def Plugins(path, **kwargs):
	return [
		PluginDescriptor(
			name="Stream Relay " + _("Repeatzap"),
			description="Stream Relay " + _("Repeatzap"),
			where = PluginDescriptor.WHERE_EXTENSIONSMENU,
			fnc=openrepeatzap,
			icon="plugin.png"),
		PluginDescriptor(
			name=_("add service to bouquet") + ' (ICAM)',
			description=_("add service to bouquet") + ' (ICAM)',
			where = PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
			fnc=addicambouquet,
			helperfnc=addicambouquethelperfnc,
			weight=24),
		PluginDescriptor(
			name=_('Add') + ' / ' + _("Remove") + ' (ICAMREF)',
			description=_('Add') + ' / ' + _("Remove") + ' (ICAMREF)',
			where = PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
			fnc=addicamref,
			helperfnc=addicamrefhelperfnc,
			weight=25),
		PluginDescriptor(
			name="Stream Relay " + _("Setup"),
			description="Stream Relay " + _("Setup"),
			where = PluginDescriptor.WHERE_PLUGINMENU,
			fnc=setup,
			icon="plugin.png"),
		PluginDescriptor(
			where = PluginDescriptor.WHERE_INFOBAR,
			fnc=infobarstart_new,
			needsRestart = True,
			weight=1000)
		]
		
#########################################################
readstreamrelayconf()

'''
def serviceEvent_ok(event, self):
	try:
		if event == 1:
			if self.has_key("StreamService"):
				eventservice = self.getRecordServiceRef()
				if eventservice:
					eventservice = self.getRecordServiceRef().toCompareString()
					for streaming in streamingScreens:
						if streaming.has_key("StreamService"):
							streamingservice = self.getRecordServiceRef()
							if streamingservice:
								streamingservice = self.getRecordServiceRef().toCompareString()
								if eventservice == streamingservice:
									streamingScreens.remove(streaming)
	except:
		writeerror()
'''

def serviceEvent(event, self):
	try:
		if event == 1:
			eventstream = self.get("StreamService")
			if eventstream and eventstream.ref:
				eventstreamcompare = eventstream.ref.toCompareString()
				if eventstreamcompare:
					for streaming in streamingScreens:
						stream = streaming.get("StreamService")
						if stream and stream.ref:
							if eventstreamcompare == stream.ref.toCompareString():
								streamingScreens.remove(streaming)
			try:
				if not self.request._disconnected:
					writelog('self.request._disconnected {0}'.format(self.request._disconnected))
					self.request.write(b"<html><body>Sorry to keep you waiting.</body></html>")
					self.request.finish()
			except:
				writeerror()
	except:
		writeerror()

#if streamrelayconf.get('icamref', None) or streamrelayconf.get('recordstate', None):
#	if serviceEvent not in streamingEvents:
#		streamingEvents.append(serviceEvent)

'''
def gotRecordEvent_timer_list(self, service, event):
	try:
		prev_records = self.records_running
		if event in [iRecordableService.evNewEventInfo, iRecordableService.evEnd, None]:
			recordres = 0
			if service:
				recslist = self.session.nav.getRecordings()
				if recslist:
					for timer in self.session.nav.RecordTimer.timer_list:
						if timer.state == TimerEntry.StateRunning and not timer.justplay and hasattr(timer, "Filename"):
							recordres += 1
						
			self.records_running = recordres
			if self.records_running != prev_records:
				self.changed((self.CHANGED_ALL,))
	except:
		writeerror()
			
def gotRecordEvent_streamingptr(self, service, event):
	try:
		prev_records = self.records_running
		if event in [iRecordableService.evNewEventInfo, iRecordableService.evEnd, None]:
			recslen = 0
			if service:
				recslist = self.session.nav.getRecordings()
				if recslist:
					streamingptr = checkstreaming()
					#recslistptr = []
					for x in recslist:
						recsptr = x.getPtrString()
						#recslistptr.append(recsptr)
						if recsptr not in streamingptr:
							recslen += 1
						
			self.records_running = recslen
			if self.records_running != prev_records:
				self.changed((self.CHANGED_ALL,))
	except:
		writeerror()

def getstreamingdata(serviceptr, event=0):
	try:
		for webscreen in streamingScreens:
			stream = webscreen.get("StreamService")
			if stream:
				#writelog('event {0} {1}'.format('0', stream))
				#writelog('stream {0}'.format(dir(stream)))
				#writelog('stream.getService {0}'.format(dir(stream.getService())))
				
				#writelog('stream.getService.stream() {0}'.format(stream.getService().stream().getStreamingData()))
				service = stream.getService()
				retval = ''
				if service is None:
					retval = "-NO SERVICE\n"
				
				elif service:
					if serviceptr == service.getPtrString():
					#if serviceptr == 'huhu':
						#writelog('event {0} ptr {1}'.format(event, service.getPtrString()))
						streaming = service.stream()
						#s = stream.getService().stream().getStreamingData()
						s = streaming and streaming.getStreamingData()
						pids = s and s.get("pids", [] )
						demux = s and s.get("demux", None)
					
						if not s or not pids or demux is None:
							err = service.getError()
							if err:
								retval = "-SERVICE ERROR:%d\n" % err
							else:
								retval = "=NO STREAM\n"
						else:
						#if retval == '':
							pids = ','.join(["%x:%s" % (x[0], x[1]) for x in pids])
							retval = "+%d:%s\n" % (demux, pids)
				
				if retval:
					webscreen.request.write(retval)
					writelog('event {0} retval {1}'.format(event, retval))
				
						#writelog('webscreen {0}'.format(dir(webscreen)))
						#writelog('webscreen.request {0}'.format(dir(webscreen.request)))
						#writelog('webscreen.request.args {0}'.format(webscreen.request.args))
	except:
		writeerror()
'''

def gotRecordEvent(self, service, event):
	try:
		#writelog('event {0} mainstreamptr {1} getRecordings {2} MycheckRecordings {3}'.format(event, mainstreamptr, len(self.session.nav.getRecordings()), MycheckRecordings(self.session)))
		prev_records = self.records_running
		if event in [iRecordableService.evNewEventInfo, iRecordableService.evEnd, None]:
			recslen = 0
			if service:
				#if event == iRecordableService.evNewEventInfo and streamingScreens:
				#	getstreamingdata(service.getPtrString(), event)
				recslen = MycheckRecordings(self.session)
				#recslist = self.session.nav.getRecordings()
				#if recslist:
				#	for x in recslist:
				#		if x.getPtrString() not in mainstreamptr:
				#			recslen += 1
						
			self.records_running = recslen
			if self.records_running != prev_records:
				self.changed((self.CHANGED_ALL,))
	except:
		writeerror()

def getRecordings(self, simulate=False):
	try:
		streamingptr = checkstreaming()
		#writelog('streamingptr {0}'.format(streamingptr))
		if streamingptr:
			recslist = self.pnav and self.pnav.getRecordings(simulate)
			if recslist:
				recsres = []
				for recs in recslist:
					#recsptr = recs.getPtrString()
					if recs.getPtrString() not in streamingptr:
						recsres.append(recs)
				#writelog('getRecordings {0}'.format(recsres))
				return recsres
				
		#else:
		#return self.pnav and self.pnav.getRecordings(simulate)
	except:
		writeerror()
	
	return self.pnav and self.pnav.getRecordings(simulate)
	
def StreamService_execBegin(self):
	try:
		self.sr_ori_execBegin()
		#writelog('execBegin {0} {1}'.format(mainstreamptr, self.request))
		_service_ = self.getService()
		if _service_:
			#self.request.write(getstreamingdata__(_service_))
			mainstreamptr.append(_service_.getPtrString())
			#writelog('execBegin {0} {1}'.format(mainstreamptr, self.ref.toString()))
	except:
		self.sr_ori_execBegin()
		writeerror()


def StreamService_execEnd(self):
	try:
		_service_ = self.getService()
		if _service_:
			ptr = _service_.getPtrString()
			#writelog('execEnd start mainstreamptr {0} ptr {1}  {2}'.format(mainstreamptr, ptr, self.ref.toString()))
			if ptr in mainstreamptr:
				mainstreamptr.remove(ptr)
			#writelog('execEnd stop mainstreamptr {0} ptr {1}  {2}'.format(mainstreamptr, ptr, self.ref.toString()))
		self.sr_ori_execEnd()
	except:
		self.sr_ori_execEnd()
		writeerror()
		
if streamrelayconf.get('recordstate', None):

	#ori_execBegin = getattr(StreamService, 'execBegin', None)
	#delattr(StreamService, 'execBegin')
	#setattr(StreamService, 'execBegin', execBegin)
	#if serviceEvent not in streamingEvents:
	#	streamingEvents.append(serviceEvent)
	
	#############################
	try:
		from Plugins.Extensions.Pineas.plugin import StreamServicePineas as StreamService
	except:
		from Components.Sources.StreamService import StreamService
	
	from Components.Sources.RecordState import RecordState
	StreamService.sr_ori_execBegin = StreamService.execBegin
	StreamService.execBegin = StreamService_execBegin
	
	StreamService.sr_ori_execEnd = StreamService.execEnd
	StreamService.execEnd = StreamService_execEnd
	RecordState.gotRecordEvent = gotRecordEvent
	#############################
	try:
		from Components.FrontPanelLed import FrontPanelLed
		def checkRecordings(self, service=None, event=iRecordableService.evNewEventInfo):
			if not self._session:
				return
			if event in [iRecordableService.evNewEventInfo, iRecordableService.evEnd]:
				recordings = MycheckRecordings(self._session)
				if recordings:
					FrontPanelLed.recording()
					#writelog('event {0} MycheckRecordings FrontPanelLed.recording()'.format(event))
				else:
					FrontPanelLed.stopRecording()
					#writelog('event {0} MycheckRecordings FrontPanelLed.stopRecording()'.format(event))
		FrontPanelLed.checkRecordings = checkRecordings
		##from API import api
		##api.setSession(session)
		#from API import session
		#from Components.FrontPanelLed import frontPanelLed
		#frontPanelLed.init(session)
	except:
		pass
		#writeerror()
	#############################
	#from Navigation import Navigation
	#ori_getRecordings = Navigation.getRecordings
	#Navigation.getRecordings = getRecordings
	#############################

def setCurrentSelection(self, service):
	try:
		if icamident and service and service.getUnsignedData(4) == 33:
			if 'compare' in icamident and icamident['compare'] == service.toCompareString():
				service = eServiceReference(icamident['servicestr'])
	except:
		writeerror()
	
	self.servicelist.setCurrent(service)

def Sr_StreamingWebScreenexecBegin(self):
	try:
		writelog('Sr_StreamingWebScreenexecBegin {0}'.format(self["StreamService"]))
		self.sr_ori_execBegin()
		#writelog('Sr_StreamingWebScreenexecBegin {0}'.format(dir(self)))
		writelog('Sr_StreamingWebScreenexecBegin {0}'.format(self["StreamService"]))
	except:
		writeerror()

def Sr_StreamingWebScreenexecEnd(self):
	try:
		self.sr_ori_execEnd()
		if self in streamingScreens:
			#writelog('streamingScreens.remove {0}'.format('True'))
			streamingScreens.remove(self)
		#else:
		#	writelog('streamingScreens.remove {0}'.format('False'))
	except:
		writeerror()
		
if streamrelayconf.get('icamref', None):
	#if serviceEvent not in streamingEvents:
	#	streamingEvents.append(serviceEvent)
	from Screens.ChannelSelection import ChannelSelectionBase
	ChannelSelectionBase.setCurrentSelection = setCurrentSelection

if streamrelayconf.get('icamref', None) or streamrelayconf.get('recordstate', None):
	from Plugins.Extensions.WebInterface.WebScreens import StreamingWebScreen
	StreamingWebScreen.sr_ori_execEnd = StreamingWebScreen.execEnd
	StreamingWebScreen.execEnd = Sr_StreamingWebScreenexecEnd
	#StreamingWebScreen.sr_ori_execBegin = StreamingWebScreen.execBegin
	#StreamingWebScreen.execBegin = Sr_StreamingWebScreenexecBegin
	
@staticmethod
def getPngName(ref, nameCache, findPicon):
	try:
		if ref and 'B:16:21' in ref:
			refstr = ref[ref.rfind('/')+1:ref.rfind(':')]
			ref = refstr.replace('%3a',':')
	except:
		writeerror()
	return ori_getPngName(ref, nameCache, findPicon)

'''
if streamrelayconf.get('referencefix', None):
	from Tools.PiconResolver import PiconResolver
	ori_getPngName = PiconResolver.getPngName
	PiconResolver.getPngName = getPngName'''

def _sr_playservice_(self):
	try:
		if self._sr_currentref_:
			#writelog('_sr_playservice_ {0}'.format(self._sr_currentref_.toString()))
			self.session.nav.playService(self._sr_currentref_, forceRestart=True)
			self._sr_currentref_ = None
	except:
		writeerror()
			
"""	
def _my_doReconnect_(self):
	try:
		if self._currentRef:
			#writelog('_my_doReconnect_ {0}'.format(self._currentRef.toString()))
			self.session.nav.playService(self._currentRef, forceRestart=True)
	except:
		writeerror()
"""

def __tuneFailed(self):
	try:
		service = self.session.nav.getCurrentService()
		info = service and service.info()
		error = info and info.getInfo(iServiceInformation.sDVBState)
		namespace = info and info.getInfo(iServiceInformation.sNamespace)
		#name = (info.getName() or "<n/a>").replace('\xc2\x86', '').replace('\xc2\x87', '')
		#writelog('error {0} service {1}'.format(error, name))
		
		if error == self.last_error:
			error = None
		else:
			self.last_error = error
		#if error in [eDVBServicePMTHandler.eventNoResources, eDVBServicePMTHandler.eventTuneFailed, eDVBServicePMTHandler.eventNoPAT]:
		if (self._isReconnect == False and error == eDVBServicePMTHandler.eventNoResources and namespace != 33) or \
		   (self._isReconnect == False and error in [eDVBServicePMTHandler.eventNoPATEntry, eDVBServicePMTHandler.eventNoPAT] and namespace == 33):
		
		#if self._isReconnect == False and (error in [eDVBServicePMTHandler.eventNoResources]) and namespace != 33:
			#if streamingScreens:
			#	checkstreaming()
			#self._isReconnect = True
			#self._reconnTimer.startLongTimer(1)
			#name = (info.getName() or "<n/a>").replace('\xc2\x86', '').replace('\xc2\x87', '')
			#self.setPlaybackState(self.MESSAGE_WAIT, name + ' ' +  _('Rezap'))
			restarttime = 1000
			if namespace == 33:
				if error != eDVBServicePMTHandler.eventNoPAT:
					restarttime = 2500
				
				self.setPlaybackState(self.STATE_RECONNECTING, self.MESSAGE_WAIT)
			#if self._sr_playServiceTimer.isActive() == False:
			self._sr_currentref_ = self._currentRef
			#self._sr_playServiceTimer.stop()
			self._sr_playServiceTimer.start(restarttime, True)
			#writelog('_reconnTimer.start {0}'.format(restarttime))
		else:
			self.last_error = None
			ori__tuneFailed(self)
	except:
		writeerror()

def setPlayableIgnoreService(self, ref):
	try:
		if ref and ref.getUnsignedData(4) == 33:
			path = ref.getPath()
			if path:
				pos = path.rfind('/')
				if pos != -1:
					refstr = path[pos+1:]
					ref = eServiceReference(refstr)
	except:
		writeerror()
		
	self.is_playable_ignore = ref
	
"""
def handleCommand(self, cmd):
	try:
		print "StreamService handle command", cmd
		mycmd = eServiceReference(cmd)
		mycmd.setSuburi(cmd)
		sid = mycmd.getUnsignedData(1)
		tsid = mycmd.getUnsignedData(2)
		mycmd.setUnsignedData(5, sid)
		mycmd.setUnsignedData(6, tsid)
		
		self.ref = mycmd
	
	except:
		writeerror()
"""
			
if streamrelayconf.get('noresourcescolor', 0) > 0:
	#from Screens.InfoBar import InfoBar
	#InfoBar._my_doReconnect_ = _my_doReconnect_
	#InfoBar._my_reconnTimer = eTimer()
	#InfoBar._my_reconnTimer_conn = InfoBar._my_reconnTimer.timeout.connect(InfoBar._my_doReconnect_)
	#InfoBar.instance._my_reconnTimer.start(1000, True)
	#from Components.Sources.StreamService import StreamService
	#StreamService.handleCommand = handleCommand
	if streamrelayconf['noresourcescolor'] in [1,3]:
		from Screens.InfoBarGenerics import InfoBarServiceErrorPopupSupport
		ori__tuneFailed = InfoBarServiceErrorPopupSupport._InfoBarServiceErrorPopupSupport__tuneFailed
		InfoBarServiceErrorPopupSupport._InfoBarServiceErrorPopupSupport__tuneFailed = __tuneFailed
	if streamrelayconf['noresourcescolor'] in [2,3]:
		from Components.ServiceList import ServiceList
		ServiceList.setPlayableIgnoreService = setPlayableIgnoreService

def _eventupdateonshow_(self):
	try:
		if self.execing and self.shown:
			if self.session.screen.has_key('Event_Now'):
				self.session.screen['Event_Now'].gotEvent(iPlayableService.evUpdatedEventInfo)
			if self.session.screen.has_key('Event_Next'):
				self.session.screen['Event_Next'].gotEvent(iPlayableService.evUpdatedEventInfo)
	except:
		writeerror()
		
def getSimilarEvents(self):
	try:
		refstr = str(self.currentService)
		id = self.event.getEventId()
		epgcache = eEPGCache.getInstance()
		ret = epgcache.search(('NBIR', 100, eEPGCache.SIMILAR_BROADCASTINGS_SEARCH, refstr, id))
		if ret is not None:
			ret1 = []
			for x in ret:
				if "-1:0:0" not in x[3]:
					ret1.append(x[:2])
			#if ret1:
			ret = ret1
			if ret:
				descr = self["epg_description"]
				text = descr.getText()
				text += '\n\n' + _('Similar broadcasts:')
				
				ret.sort(self.sort_func)
				for x in ret:
					t = localtime(x[1])
					text += '\n%d.%d.%d, %02d:%02d  -  %s'%(t[2], t[1], t[0], t[3], t[4], x[0])
				descr.setText(text)
				self["key_red"].setText(_("Similar"))
	except:
		writeerror()

def fillSimilarList(self, refstr, event_id):
	try:
		if event_id is None:
			return
		self.list = self.epgcache.search(('RIBDN', 1024, eEPGCache.SIMILAR_BROADCASTINGS_SEARCH, refstr, event_id))
		ret1 = []
		
		for x in self.list:
			if "-1:0:0" not in x[0]:
				ret1.append(x)

			#if ret1:
		self.list = ret1
		
		if self.list and len(self.list):
			self.list.sort(key=lambda x: x[2])
		self.l.setList(self.list)
		self.selectionChanged()
		
	except:
		writeerror()
		
if streamrelayconf.get('eventupdateonshow', None):

	from Screens.EventView import EventViewBase
	EventViewBase.getSimilarEvents = getSimilarEvents
	
	from Components.EpgList import EPGList
	EPGList.fillSimilarList = fillSimilarList



def havepmt(service):
	pmt = False
	streaming = service.stream()
	s = streaming and streaming.getStreamingData()
	pids = s and s.get("pids", [] )
	if pids:
		for value, key in pids:
			if key == "pmt":
				return True
	return pmt
	
def sr_recordEvent(self, service, event):
	try:
		#writelog('event {0} service {1}'.format(event, service and True or False))
		if service is self.getService():
			#writelog('event {0} service is self.__service {1}'.format(event, service is self._StreamService__service))
			return
		print "RECORD event for us:", service
		if event in [iRecordableService.evStart]:
			return
			#self.changed((self.CHANGED_DEFAULT, ))
		elif event in [iRecordableService.evEnd, iRecordableService.evRecordStopped]:
			self.changed((self.CHANGED_CLEAR, ))
		elif event in [iRecordableService.evRecordRunning, iRecordableService.evNewProgramInfo, iRecordableService.evNewEventInfo]:
			#writelog('event {0} service {1}'.format(event, ''))
			#if havepmt(service):
			self.changed((self.CHANGED_ALL, ))
	except:
		writeerror()
		self.recordEvent_srori(service, event)

def sr_recordEvent_hp(self, service, event):
	try:
		#writelog('event {0} self.havepids {1}'.format(event, self.havepids))
		if service is self.getService():
			#writelog('event {0} service is self.__service {1}'.format(event, service is self.getService()))
			return
		print "RECORD event for us:", service
		if event in [iRecordableService.evStart]:
			self.havepids = False
		elif self.havepids == False and event in [iRecordableService.evRecordRunning, iRecordableService.evNewProgramInfo, iRecordableService.evNewEventInfo]:
			self.changed((self.CHANGED_ALL, ))
			#self.havepids = True
	except:
		writeerror()
		self.recordEvent_srori(service, event)

if streamrelayconf.get('requestfilter', 0) == 1:
	try:
		from Plugins.Extensions.Pineas.plugin import StreamServicePineas as StreamService
	except:
		from Components.Sources.StreamService import StreamService
	
	StreamService.recordEvent_srori = StreamService.recordEvent
	#StreamService.havepids = False
	StreamService.recordEvent = sr_recordEvent
	
	from Components.Converter.Streaming import Streaming
	from Plugins.Extensions.StreamRelay.Streaming import Streaming as SR_Streaming

	Streaming.getText = SR_Streaming.getText
	Streaming.text = SR_Streaming.text

elif streamrelayconf.get('requestfilter', 0) == 2:
	try:
		from Plugins.Extensions.Pineas.plugin import StreamServicePineas as StreamService
	except:
		from Components.Sources.StreamService import StreamService
	
	StreamService.recordEvent_srori = StreamService.recordEvent
	#StreamService.havepids = False
	StreamService.recordEvent = sr_recordEvent
	
	from Components.Converter.Streaming import Streaming
	from Plugins.Extensions.StreamRelay.Streaming import Streaming2 as SR_Streaming

	Streaming.getText = SR_Streaming.getText
	Streaming.text = SR_Streaming.text

elif streamrelayconf.get('requestfilter', 0) == 3:
	try:
		from Plugins.Extensions.Pineas.plugin import StreamServicePineas as StreamService
	except:
		from Components.Sources.StreamService import StreamService
	
	StreamService.recordEvent_srori = StreamService.recordEvent
	StreamService.havepids = False
	StreamService.recordEvent = sr_recordEvent_hp
	
	from Components.Converter.Streaming import Streaming
	from Plugins.Extensions.StreamRelay.Streaming import Streaming3 as SR_Streaming

	Streaming.getText = SR_Streaming.getText
	Streaming.text = SR_Streaming.text
	
def __eventInfoChanged(self):
	try:
		#writelog('__eventInfoChanged {0}'.format('__eventInfoChanged'))
		if self.execing:
			service = self.session.nav.getCurrentService()
			old_begin_time = self.current_begin_time
			info = service and service.info()
			ptr = info and info.getEvent(0)
			if ptr is None:
				ref = self.session.nav.getCurrentlyPlayingServiceReference()
				if ref and ref.getUnsignedData(4) == 33:
					path = ref.getPath()
					if path:
						pos = path.rfind('/')
						if pos != -1:
							refstr = path[pos+1:]
							ref = eServiceReference(refstr)
							#serviceHandler = eServiceCenter.getInstance()
							#info = serviceHandler.play(ref)
							epg = eEPGCache.getInstance()
							ptr = epg.lookupEventTime(ref, -1, 0)
							if ptr:
								writelog('ptr {0}'.format(ptr.getBeginTime()))
							
			self.current_begin_time = ptr and ptr.getBeginTime() or 0
			#writelog('self.current_begin_time {0}'.format(self.current_begin_time))
			if config.usage.show_infobar_on_event_change.value:
				if old_begin_time and old_begin_time != self.current_begin_time:
					self.doShow()
	except:
		writeerror()
		
#from Screens.InfoBar import InfoBar
#InfoBar._InfoBar__eventInfoChanged = __eventInfoChanged

def stream_ref_to_es_ref(ref=None, tostring=None):
	try:
		if ref and ref.getUnsignedData(4) == 33:
		#if ref:
			path = ref.getPath()
			if path:
				pos = path.rfind('/')
				if pos != -1:
					refstr = path[pos+1:]
					if tostring:
						return refstr
					ref = eServiceReference(refstr)
		return ref
	except:
		writeerror()
		return ref
		
def getRecordableServicePtr():
	try:
		refres = None
		if streamingScreens:
			import NavigationInstance
			ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
			if ref and ref.getUnsignedData(4) == 33:
				for streaming in streamingScreens:
					stream = streaming.get("StreamService")
					if stream and stream.ref:
						if stream.ref.toCompareString() in (ref.getPath() or ''):
							refres = stream.getService()
		return refres
	except:
		writeerror()

def sr_activate(self):
	try:
		if self.state == self.StateWaiting and self.first_try_prepare:
			sr_ref = self.service_ref and self.service_ref.ref
			if sr_ref and sr_ref.getUnsignedData(4) == 33:
				ref = stream_ref_to_es_ref(sr_ref)
				if ref:
					service_center = eServiceCenter.getInstance()
					service_info = service_center.info(ref)
					isPlayable = service_info.isPlayable(ref, eServiceReference())
					#writelog('{} isPlayable {}'.format(sr_ref.getName(), isPlayable))
					if isPlayable == 0:
						self.first_try_prepare = False
						Notifications.AddNotification(MessageBox, _("In order to record a timer, the TV was switched to the recording service!\n"), type=MessageBox.TYPE_INFO, timeout=20,windowTitle='Streamrelay', domain="RecordTimer")
						self.failureCB(True)
						
		return self.activate_srori()
	except:
		writeerror()
		return self.activate_srori()

def sr_activate_all(self):
	try:
		if self.state == self.StateWaiting and self.first_try_prepare:
			sr_ref = self.service_ref and self.service_ref.ref
			
			if sr_ref and sr_ref.getUnsignedData(4) != 33:
				servicestr = sr_ref.toString()
				if servicestr and icamref and servicestr in icamref:
					name = (self.service_ref.getServiceName() or "").replace('\xc2\x86', '').replace('\xc2\x87', '') or (icamref[servicestr] and icamref[servicestr].encode('utf-8')) or '<n/a>'
					if streamrelayconf['nameadd']:
						name += ' ' + streamrelayconf['nameadd']
					sr_ref.setName('{0}'.format(name))
					sr_ref.setUnsignedData(4, 33)
					sr_ref.setPath('http://{0}:{1}/{2}'.format(streamrelayconf['streamhost'], streamrelayconf['streamport'], servicestr))
					self.service_ref.ref = sr_ref
			if sr_ref and sr_ref.getUnsignedData(4) == 33:
				ref = stream_ref_to_es_ref(sr_ref)
				if ref:
					service_center = eServiceCenter.getInstance()
					service_info = service_center.info(ref)
					isPlayable = service_info.isPlayable(ref, eServiceReference())
					#writelog('{} isPlayable {}'.format(sr_ref.getName(), isPlayable))
					if isPlayable == 0:
						self.first_try_prepare = False
						Notifications.AddNotification(MessageBox, _("In order to record a timer, the TV was switched to the recording service!\n"), type=MessageBox.TYPE_INFO, timeout=20,windowTitle='Streamrelay', domain="RecordTimer")
						self.failureCB(True)
						
		return self.activate_srori()
	except:
		writeerror()
		return self.activate_srori()
		
if streamrelayconf.get('switchrecording', None):
	try:
		from Tools import Notifications
		try:
			from Plugins.Extensions.Pineas.plugin import activatePineas
			RecordTimerEntry.activate_srori = activatePineas
		except:
			from RecordTimer import RecordTimerEntry
			RecordTimerEntry.activate_srori = RecordTimerEntry.activate
			
		RecordTimerEntry.activate = sr_activate_all
	except:
		writeerror()
		